/**
 * activity-log.js — Activity Log Viewer Module
 */
import { Activity } from '../data.js';
import { t, formatDateTime } from '../i18n.js';
import { escHtml, showConfirm, showToast, openModal, closeModal } from '../app.js';

let filterType = 'all';
let searchQuery = '';

export function render(container) {
  container.innerHTML = buildPage();
  lucide.createIcons();
  bindEvents(container);
}

function buildPage() {
  const all = Activity.getAll();
  const today = new Date().toISOString().slice(0,10);
  const todayCount = all.filter(a => a.createdAt?.slice(0,10) === today).length;
  const checkinCount = all.filter(a => a.type === 'checkin').length;
  const checkoutCount = all.filter(a => a.type === 'checkout').length;

  const filtered = getFiltered();

  return `
  <div class="page-enter">
    <div class="page-header">
      <div class="page-header-left">
        <h1>${t('alog.title')}</h1>
        <p>${t('alog.subtitle')}</p>
      </div>
      <div class="page-header-actions">
        <button class="btn btn-danger" id="clear-activity-btn">
          <i data-lucide="trash-2"></i> ${t('alog.clear')}
        </button>
      </div>
    </div>

    <div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
      <div class="stat-card stat-blue">
        <div class="stat-icon"><i data-lucide="activity"></i></div>
        <div class="stat-value">${all.length}</div>
        <div class="stat-label">${t('alog.total')}</div>
      </div>
      <div class="stat-card stat-green">
        <div class="stat-icon"><i data-lucide="calendar-check"></i></div>
        <div class="stat-value">${todayCount}</div>
        <div class="stat-label">${t('alog.today')}</div>
      </div>
      <div class="stat-card stat-gold">
        <div class="stat-icon"><i data-lucide="log-in"></i></div>
        <div class="stat-value">${checkinCount}</div>
        <div class="stat-label">${t('alog.checkins')}</div>
      </div>
      <div class="stat-card stat-purple">
        <div class="stat-icon"><i data-lucide="log-out"></i></div>
        <div class="stat-value">${checkoutCount}</div>
        <div class="stat-label">${t('alog.checkouts')}</div>
      </div>
    </div>

    <div style="display:flex;gap:12px;align-items:center;margin-bottom:20px;flex-wrap:wrap">
      <div class="search-bar" style="flex:1;min-width:200px;max-width:360px">
        <i data-lucide="search"></i>
        <input class="search-input" id="activity-search" placeholder="${t('common.search')}" value="${escHtml(searchQuery)}">
      </div>
    </div>

    <div class="filter-bar" style="margin-bottom:20px">
      <button class="filter-btn ${filterType==='all'?'active':''}" data-filter="all">${t('common.all')}</button>
      <button class="filter-btn ${filterType==='checkin'?'active':''}" data-filter="checkin">Check-ins</button>
      <button class="filter-btn ${filterType==='checkout'?'active':''}" data-filter="checkout">Check-outs</button>
      <button class="filter-btn ${filterType==='service'?'active':''}" data-filter="service">Services</button>
      <button class="filter-btn ${filterType==='expense'?'active':''}" data-filter="expense">Expenses</button>
      <button class="filter-btn ${filterType==='cancel'?'active':''}" data-filter="cancel">Cancelled</button>
      <button class="filter-btn ${filterType==='info'?'active':''}" data-filter="info">Info</button>
    </div>

    ${filtered.length === 0
      ? `<div class="empty-state">
           <div class="empty-icon"><i data-lucide="scroll-text"></i></div>
           <h3>${t('alog.no_activity')}</h3>
         </div>`
      : `<div class="card">
           <div style="padding:4px 0">
             ${filtered.map(a => `
               <div class="activity-item" style="padding:12px 16px">
                 <div class="activity-dot ${dotClass(a.type)}"></div>
                 <div style="flex:1;min-width:0">
                   <div class="activity-text">${escHtml(a.message)}</div>
                   <div class="activity-time">${formatDateTime(a.createdAt)}</div>
                 </div>
                 <span class="badge badge-${badgeClass(a.type)}" style="font-size:10px;padding:2px 8px">${a.type}</span>
               </div>
             `).join('')}
           </div>
         </div>`
    }
  </div>`;
}

function getFiltered() {
  let items = Activity.getAll();
  if (filterType !== 'all') {
    items = items.filter(a => a.type === filterType);
  }
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    items = items.filter(a => a.message?.toLowerCase().includes(q));
  }
  return items;
}

function dotClass(type) {
  const map = { checkin:'dot-green', checkout:'dot-blue', service:'dot-orange', expense:'dot-red', cancel:'dot-red', info:'dot-blue' };
  return map[type] || 'dot-blue';
}

function badgeClass(type) {
  const map = { checkin:'active', checkout:'completed', service:'pending', expense:'cancelled', cancel:'cancelled', info:'pending' };
  return map[type] || 'pending';
}

function bindEvents(container) {
  let searchTimer;
  container.querySelector('#activity-search')?.addEventListener('input', e => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      searchQuery = e.target.value.trim();
      render(container);
    }, 250);
  });

  container.addEventListener('click', e => {
    const btn = e.target.closest('button, [data-filter]');
    if (!btn) return;

    if (btn.id === 'clear-activity-btn') {
      showConfirm(t('alog.clear'), t('alog.clear_confirm'), () => {
        localStorage.setItem('ghms_activity', JSON.stringify([]));
        showToast('Cleared', 'Activity log has been cleared', 'success');
        render(container);
      });
    } else if (btn.dataset.filter !== undefined) {
      filterType = btn.dataset.filter;
      render(container);
    }
  });
}