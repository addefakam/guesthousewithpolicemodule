/**
 * calendar.js — Calendar View Module
 * Monthly room-booking calendar grid for Guest House Management System
 */
import { Reservations, Rooms, Guests } from '../data.js';
import { t, formatCurrency, formatDate } from '../i18n.js';
import { showToast, escHtml, openModal, closeModal } from '../app.js';

// ============================================================
// STATE
// ============================================================
let viewYear, viewMonth; // month is 0-indexed (JS Date convention)
const CELL_W = 36;       // px per day column
const ROW_H  = 44;       // px per room row
const BLOCK_PAD = 3;     // px vertical padding inside row for blocks

// ============================================================
// HELPERS
// ============================================================
function initDate() {
  const now = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();
}

function daysInMonth(y, m) {
  return new Date(y, m + 1, 0).getDate();
}

function dayOfWeek(y, m, d) {
  return new Date(y, m, d).getDay(); // 0 = Sun
}

function isWeekend(y, m, d) {
  const dow = dayOfWeek(y, m, d);
  return dow === 0 || dow === 6;
}

function isToday(y, m, d) {
  const now = new Date();
  return now.getFullYear() === y && now.getMonth() === m && now.getDate() === d;
}

function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').slice(0, 2).map(w => (w[0] || '').toUpperCase()).join('');
}

function monthLabel(y, m) {
  const months = t('months');
  return `${months[m]} ${y}`;
}

// ============================================================
// STATUS COLORS
// ============================================================
function statusColors(status) {
  switch (status) {
    case 'active':    return { bg: 'rgba(59,130,246,0.15)',  border: '#3b82f6', text: '#2563eb' };
    case 'upcoming':  return { bg: 'rgba(34,197,94,0.15)',   border: '#22c55e', text: '#16a34a' };
    case 'completed': return { bg: 'rgba(156,163,175,0.18)', border: '#9ca3af', text: '#6b7280' };
    case 'cancelled': return { bg: 'rgba(239,68,68,0.12)',  border: '#ef4444', text: '#ef4444' };
    default:          return { bg: 'rgba(156,163,175,0.18)', border: '#9ca3af', text: '#6b7280' };
  }
}

function statusBadge(status) {
  const map = {
    active:    { label: t('res.active'),    cls: 'badge-active' },
    upcoming:  { label: t('res.upcoming'),  cls: 'badge-upcoming' },
    completed: { label: t('res.completed'), cls: 'badge-completed' },
    cancelled: { label: t('res.cancelled'), cls: 'badge-cancelled' },
  };
  const info = map[status] || map.upcoming;
  return `<span class="badge ${info.cls}">${info.label}</span>`;
}

function paymentBadge(pStatus) {
  const map = {
    paid:    { label: t('res.paid_lbl'), cls: 'badge-active' },
    partial: { label: t('res.partial'),  cls: 'badge-upcoming' },
    pending: { label: t('res.pending'),  cls: 'badge-completed' },
  };
  const info = map[pStatus] || map.pending;
  return `<span class="badge ${info.cls}">${info.label}</span>`;
}

// ============================================================
// DATA — reservations visible in the given month
// ============================================================
function getReservationsForMonth(y, m) {
  const dim = daysInMonth(y, m);
  const ms  = new Date(y, m, 1).toISOString().slice(0, 10);
  const me  = new Date(y, m, dim).toISOString().slice(0, 10);

  return Reservations.getAll()
    .filter(r => r.status !== 'cancelled' && r.checkIn && r.checkOut)
    .filter(r => r.checkIn <= me && r.checkOut > ms)
    .map(r => ({
      ...r,
      _guest: Guests.getById(r.guestId),
      _room:  Rooms.getById(r.roomId),
    }));
}

// Visible block geometry for a reservation within the month grid
function blockGeometry(res, y, m) {
  const dim = daysInMonth(y, m);
  const ci  = new Date(res.checkIn + 'T00:00:00');
  const co  = new Date(res.checkOut + 'T00:00:00');
  const mFirst = new Date(y, m, 1);
  const mLast  = new Date(y, m, dim + 1); // day after month end

  // Day-of-month (1-based) for visible start/end
  let startDay = ci >= mFirst ? ci.getDate() : 1;
  let endDay   = co <= mLast  ? co.getDate() : dim + 1;

  startDay = Math.max(1, Math.min(dim + 1, startDay));
  endDay   = Math.max(startDay, Math.min(dim + 1, endDay));

  if (startDay >= endDay) return null; // no visible portion

  return {
    left:     (startDay - 1) * CELL_W,
    width:    (endDay - startDay) * CELL_W,
    startDay,
    endDay,
  };
}

// ============================================================
// CALENDAR-SPECIFIC STYLES (injected once)
// ============================================================
let stylesInjected = false;
function injectStyles() {
  if (stylesInjected) return;
  stylesInjected = true;
  const style = document.createElement('style');
  style.textContent = `
    /* Calendar day header */
    .cal-day-hdr {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4px 0 6px;
      font-size: 12px;
      font-weight: 600;
      color: var(--text-secondary);
      border-right: 1px solid var(--border);
      user-select: none;
    }
    .cal-day-hdr .cal-day-num { font-size: 13px; font-weight: 700; color: var(--text-primary); line-height: 1.2; }
    .cal-day-hdr .cal-day-dow { font-size: 9px; font-weight: 500; color: var(--text-muted); line-height: 1.2; margin-top: 1px; }
    .cal-day-hdr.cal-weekend .cal-day-num { color: var(--red); }
    .cal-day-hdr.cal-today .cal-day-num {
      background: var(--blue);
      color: #fff;
      width: 22px;
      height: 22px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      line-height: 1;
    }

    /* Calendar cell */
    .cal-cell {
      border-right: 1px solid var(--border);
      border-bottom: 1px solid var(--border);
    }
    .cal-cell.cal-weekend-cell { background: rgba(239,68,68,0.04); }
    .cal-cell.cal-today-cell  { background: rgba(59,130,246,0.06); }

    /* Calendar room label */
    .cal-room-label {
      font-size: 12px;
      font-weight: 600;
      color: var(--text-primary);
      border-right: 1px solid var(--border);
      background: var(--bg-card);
      position: sticky;
      left: 0;
      z-index: 1;
    }

    /* Calendar row */
    .cal-row { border-bottom: 1px solid var(--border); }
    .cal-row:last-child { border-bottom: none; }
    .cal-row:hover { background: var(--bg-elevated); }

    /* Reservation block */
    .cal-block {
      position: absolute;
      border-radius: 4px;
      cursor: pointer;
      display: flex;
      align-items: center;
      padding: 0 6px;
      overflow: hidden;
      z-index: 2;
      transition: filter 0.15s, box-shadow 0.15s;
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.02em;
    }
    .cal-block:hover {
      filter: brightness(1.1);
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      z-index: 3;
    }

    /* Legend */
    .cal-legend-item {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: var(--text-secondary);
    }
    .cal-legend-swatch {
      width: 16px;
      height: 12px;
      border-radius: 3px;
      flex-shrink: 0;
    }

    /* Mobile reservation card */
    .cal-mobile-card {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 12px;
      border-radius: 8px;
      cursor: pointer;
      margin-bottom: 6px;
      transition: filter 0.15s;
    }
    .cal-mobile-card:hover { filter: brightness(1.05); }

    /* Scrollbar */
    #cal-scroll::-webkit-scrollbar { height: 6px; }
    #cal-scroll::-webkit-scrollbar-track { background: var(--bg-elevated); border-radius: 3px; }
    #cal-scroll::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
  `;
  document.head.appendChild(style);
}

// ============================================================
// DESKTOP GRID VIEW
// ============================================================
function buildDesktopView() {
  const rooms   = Rooms.getAll().sort((a, b) =>
    (a.number || '').localeCompare(b.number || '', undefined, { numeric: true })
  );
  const resList = getReservationsForMonth(viewYear, viewMonth);
  const dim     = daysInMonth(viewYear, viewMonth);
  const DOW     = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  // ---- Day column headers ----
  let dayHeaders = '';
  for (let d = 1; d <= dim; d++) {
    const we  = isWeekend(viewYear, viewMonth, d) ? 'cal-weekend' : '';
    const td  = isToday(viewYear, viewMonth, d)   ? 'cal-today'   : '';
    const brd = d === dim ? '' : 'border-right:1px solid var(--border);';
    dayHeaders += `
      <div class="cal-day-hdr ${we} ${td}" style="width:${CELL_W}px;flex-shrink:0;${brd}">
        <span class="cal-day-num">${d}</span>
        <span class="cal-day-dow">${DOW[dayOfWeek(viewYear, viewMonth, d)]}</span>
      </div>`;
  }

  // ---- Room rows ----
  let roomRows = '';
  if (rooms.length === 0) {
    roomRows = `
      <div class="empty-state" style="padding:48px 24px">
        <div class="empty-icon"><i data-lucide="door-open"></i></div>
        <h3>${t('room.no_rooms')}</h3>
        <p>${t('room.add_first')}</p>
      </div>`;
  } else {
    rooms.forEach(room => {
      const roomRes = resList.filter(r => r.roomId === room.id);

      // Day cells (grid lines)
      let cells = '';
      for (let d = 1; d <= dim; d++) {
        const we  = isWeekend(viewYear, viewMonth, d) ? 'cal-weekend-cell' : '';
        const td  = isToday(viewYear, viewMonth, d)   ? 'cal-today-cell'   : '';
        const brd = d === dim ? '' : 'border-right:1px solid var(--border);';
        cells += `<div class="cal-cell ${we} ${td}" style="width:${CELL_W}px;flex-shrink:0;${brd}"></div>`;
      }

      // Reservation blocks
      let blocks = '';
      roomRes.forEach(r => {
        const geo = blockGeometry(r, viewYear, viewMonth);
        if (!geo) return;
        const c  = statusColors(r.status);
        const ini = getInitials(r._guest?.name);
        const showText = geo.width >= CELL_W * 1.8;
        blocks += `
          <div class="cal-block" data-res-id="${escHtml(r.id)}"
               style="left:${geo.left}px;width:${geo.width}px;top:${BLOCK_PAD}px;bottom:${BLOCK_PAD}px;
                      background:${c.bg};border-left:3px solid ${c.border};color:${c.text};"
               title="${escHtml(r._guest?.name || 'Guest')} — ${r._room?.number || '?'}">
            ${showText ? `<span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(ini)}</span>` : ''}
          </div>`;
      });

      roomRows += `
        <div class="cal-row" style="display:flex;align-items:stretch;min-height:${ROW_H}px">
          <div class="cal-room-label" style="width:110px;flex-shrink:0;display:flex;align-items:center;gap:6px;padding:0 10px">
            <span style="width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;
                         font-size:10px;font-weight:700;background:var(--bg-elevated);color:var(--text-secondary);flex-shrink:0">
              ${escHtml(room.number)}
            </span>
            <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escHtml(room.name || room.number)}">
              ${escHtml(room.name || '')}
            </span>
          </div>
          <div style="position:relative;display:flex;flex:1">
            ${cells}
            ${blocks}
          </div>
        </div>`;
    });
  }

  // ---- Occupancy mini-stats ----
  const totalNights = resList.reduce((s, r) => s + (r.nights || 0), 0);
  const uniqueRooms = new Set(resList.map(r => r.roomId)).size;

  return `
    <!-- Month Navigation -->
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;flex-wrap:wrap">
      <button class="btn btn-ghost btn-sm" id="cal-prev" aria-label="Previous month">
        <i data-lucide="chevron-left" style="width:16px;height:16px"></i>
      </button>
      <h2 id="cal-month-label" style="font-size:18px;font-weight:700;min-width:160px;text-align:center;margin:0">
        ${monthLabel(viewYear, viewMonth)}
      </h2>
      <button class="btn btn-ghost btn-sm" id="cal-next" aria-label="Next month">
        <i data-lucide="chevron-right" style="width:16px;height:16px"></i>
      </button>
      <button class="btn btn-secondary btn-sm" id="cal-today" style="margin-left:8px">
        <i data-lucide="calendar-check" style="width:14px;height:14px"></i> Today
      </button>
    </div>

    <!-- Mini stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:16px">
      <div class="stat-card stat-blue">
        <div class="stat-value">${resList.length}</div>
        <div class="stat-label">${t('nav.reservations')}</div>
      </div>
      <div class="stat-card stat-green">
        <div class="stat-value">${uniqueRooms}</div>
        <div class="stat-label">${t('nav.rooms')} ${t('dash.occupancy').toLowerCase()}</div>
      </div>
      <div class="stat-card stat-gold">
        <div class="stat-value">${totalNights}</div>
        <div class="stat-label">${t('res.nights')} ${t('common.of').toLowerCase()} ${t('nav.reservations').toLowerCase()}</div>
      </div>
    </div>

    <!-- Calendar Grid -->
    <div class="card" style="padding:0;overflow:hidden">
      <div id="cal-scroll" style="overflow-x:auto;max-height:62vh">
        <!-- Sticky day header row -->
        <div style="display:flex;align-items:stretch;border-bottom:2px solid var(--border);
                    position:sticky;top:0;z-index:3;background:var(--bg-card)">
          <div style="width:110px;flex-shrink:0;border-right:1px solid var(--border)"></div>
          <div style="display:flex">
            ${dayHeaders}
          </div>
        </div>
        <!-- Room rows -->
        ${roomRows}
      </div>
    </div>

    <!-- Legend -->
    <div style="display:flex;gap:20px;margin-top:14px;flex-wrap:wrap">
      ${buildLegend()}
    </div>`;
}

// ============================================================
// MOBILE LIST VIEW
// ============================================================
function buildMobileView() {
  const resList = getReservationsForMonth(viewYear, viewMonth);
  const rooms   = Rooms.getAll().sort((a, b) =>
    (a.number || '').localeCompare(b.number || '', undefined, { numeric: true })
  );

  let sections = '';
  rooms.forEach(room => {
    const roomRes = resList.filter(r => r.roomId === room.id);
    if (roomRes.length === 0) return;

    const cards = roomRes.map(r => {
      const c   = statusColors(r.status);
      const ini = getInitials(r._guest?.name);
      return `
        <div class="cal-mobile-card" data-res-id="${escHtml(r.id)}"
             style="background:${c.bg};border-left:3px solid ${c.border}">
          <div style="width:34px;height:34px;border-radius:8px;display:flex;align-items:center;justify-content:center;
                      font-size:12px;font-weight:700;background:${c.border};color:#fff;flex-shrink:0">
            ${escHtml(ini)}
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:13px;font-weight:600;color:var(--text-primary);
                        white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
              ${escHtml(r._guest?.name || 'Guest')}
            </div>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:1px">
              ${formatDate(r.checkIn)} &rarr; ${formatDate(r.checkOut)}
            </div>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-size:12px;font-weight:600;color:var(--text-primary)">
              ${formatCurrency(r.totalCost)}
            </div>
            <div style="margin-top:2px">${statusBadge(r.status)}</div>
          </div>
        </div>`;
    }).join('');

    sections += `
      <div style="margin-bottom:20px">
        <div style="font-size:13px;font-weight:700;color:var(--text-primary);margin-bottom:8px;
                    display:flex;align-items:center;gap:6px">
          <i data-lucide="door-open" style="width:14px;height:14px"></i>
          ${escHtml(room.number)}${room.name ? ` — ${escHtml(room.name)}` : ''}
        </div>
        ${cards}
      </div>`;
  });

  const emptyContent = rooms.length === 0
    ? `<div class="empty-state" style="padding:48px 24px">
         <div class="empty-icon"><i data-lucide="door-open"></i></div>
         <h3>${t('room.no_rooms')}</h3>
         <p>${t('room.add_first')}</p>
       </div>`
    : sections.length === 0
      ? `<div class="empty-state" style="padding:48px 24px">
           <div class="empty-icon"><i data-lucide="calendar-x"></i></div>
           <h3>No reservations this month</h3>
         </div>`
      : sections;

  return `
    <!-- Month Navigation -->
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;flex-wrap:wrap">
      <button class="btn btn-ghost btn-sm" id="cal-prev">
        <i data-lucide="chevron-left" style="width:16px;height:16px"></i>
      </button>
      <h2 id="cal-month-label" style="font-size:18px;font-weight:700;min-width:160px;text-align:center;margin:0">
        ${monthLabel(viewYear, viewMonth)}
      </h2>
      <button class="btn btn-ghost btn-sm" id="cal-next">
        <i data-lucide="chevron-right" style="width:16px;height:16px"></i>
      </button>
      <button class="btn btn-secondary btn-sm" id="cal-today" style="margin-left:8px">
        <i data-lucide="calendar-check" style="width:14px;height:14px"></i> Today
      </button>
    </div>

    <div class="card" style="padding:16px">
      ${emptyContent}
    </div>

    <!-- Legend -->
    <div style="display:flex;gap:20px;margin-top:14px;flex-wrap:wrap">
      ${buildLegend()}
    </div>`;
}

// ============================================================
// LEGEND
// ============================================================
function buildLegend() {
  const items = [
    { status: 'active',    label: t('res.active') },
    { status: 'upcoming',  label: t('res.upcoming') },
    { status: 'completed', label: t('res.completed') },
  ];
  return items.map(item => {
    const c = statusColors(item.status);
    return `<div class="cal-legend-item">
      <div class="cal-legend-swatch" style="background:${c.bg};border-left:3px solid ${c.border}"></div>
      <span>${escHtml(item.label)}</span>
    </div>`;
  }).join('');
}

// ============================================================
// RESERVATION DETAIL MODAL
// ============================================================
function showReservationModal(res) {
  const guest   = Guests.getById(res.guestId);
  const room    = Rooms.getById(res.roomId);
  const balance = (parseFloat(res.totalCost) || 0) - (parseFloat(res.paidAmount) || 0);
  const nights  = res.nights || Reservations.calcNights(res.checkIn, res.checkOut);

  openModal(t('res.title'), `
    <div class="modal-body">
      <!-- Guest & Status -->
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px">
        <div class="guest-avatar" style="width:44px;height:44px;font-size:16px;flex-shrink:0">
          ${getInitials(guest?.name)}
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-size:15px;font-weight:700;color:var(--text-primary);
                      white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
            ${escHtml(guest?.name || 'Guest')}
          </div>
          ${guest?.phone ? `<div style="font-size:12px;color:var(--text-secondary)">${escHtml(guest.phone)}</div>` : ''}
        </div>
        <div style="flex-shrink:0">${statusBadge(res.status)}</div>
      </div>

      <!-- Details Grid -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
        <div style="padding:10px 12px;border-radius:8px;background:var(--bg-elevated)">
          <div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px">${t('res.room')}</div>
          <div style="font-size:14px;font-weight:600;color:var(--text-primary)">
            <i data-lucide="door-open" style="width:13px;height:13px;display:inline;vertical-align:-2px"></i>
            ${escHtml(room?.number || '?')}${room?.name ? ` — ${escHtml(room.name)}` : ''}
          </div>
        </div>
        <div style="padding:10px 12px;border-radius:8px;background:var(--bg-elevated)">
          <div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px">${t('res.nights')}</div>
          <div style="font-size:14px;font-weight:600;color:var(--text-primary)">
            ${nights} ${t('common.days')}
          </div>
        </div>
        <div style="padding:10px 12px;border-radius:8px;background:var(--bg-elevated)">
          <div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px">${t('common.checkin')}</div>
          <div style="font-size:13px;font-weight:600;color:var(--text-primary)">${formatDate(res.checkIn)}</div>
        </div>
        <div style="padding:10px 12px;border-radius:8px;background:var(--bg-elevated)">
          <div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px">${t('common.checkout')}</div>
          <div style="font-size:13px;font-weight:600;color:var(--text-primary)">${formatDate(res.checkOut)}</div>
        </div>
      </div>

      <!-- Financial Summary -->
      <div style="padding:12px;border-radius:8px;background:var(--bg-elevated);margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <span style="font-size:13px;color:var(--text-secondary)">${t('res.total')}</span>
          <span style="font-size:15px;font-weight:700;color:var(--text-primary)">${formatCurrency(res.totalCost)}</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <span style="font-size:13px;color:var(--text-secondary)">${t('res.paid')}</span>
          <span style="font-size:14px;font-weight:600;color:var(--green)">${formatCurrency(res.paidAmount)}</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <span style="font-size:13px;color:var(--text-secondary)">${t('res.balance')}</span>
          <span style="font-size:14px;font-weight:600;color:${balance > 0.01 ? 'var(--red)' : 'var(--green)'}">
            ${formatCurrency(balance)}
          </span>
        </div>
        <div style="height:1px;background:var(--border);margin:10px 0"></div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:13px;color:var(--text-secondary)">${t('res.payment_status')}</span>
          ${paymentBadge(res.paymentStatus)}
        </div>
      </div>

      ${res.notes ? `
      <div style="padding:10px 12px;border-radius:8px;background:var(--bg-elevated);margin-bottom:16px">
        <div style="font-size:11px;color:var(--text-secondary);margin-bottom:4px">${t('common.notes')}</div>
        <div style="font-size:13px;color:var(--text-primary);white-space:pre-wrap">${escHtml(res.notes)}</div>
      </div>` : ''}

      <div class="form-actions">
        <button type="button" class="btn btn-ghost" id="cal-modal-close">${t('common.close')}</button>
      </div>
    </div>
  `);

  lucide.createIcons();
  document.getElementById('cal-modal-close')?.addEventListener('click', closeModal);
}

// ============================================================
// EVENTS
// ============================================================
function bindEvents(container) {
  // Previous month
  container.querySelector('#cal-prev')?.addEventListener('click', () => {
    viewMonth--;
    if (viewMonth < 0) { viewMonth = 11; viewYear--; }
    refreshView(container);
  });

  // Next month
  container.querySelector('#cal-next')?.addEventListener('click', () => {
    viewMonth++;
    if (viewMonth > 11) { viewMonth = 0; viewYear++; }
    refreshView(container);
  });

  // Today
  container.querySelector('#cal-today')?.addEventListener('click', () => {
    const now = new Date();
    viewYear  = now.getFullYear();
    viewMonth = now.getMonth();
    refreshView(container);
  });

  // Reservation block clicks (event delegation)
  container.querySelectorAll('[data-res-id]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      const resId = el.getAttribute('data-res-id');
      const res   = Reservations.getById(resId);
      if (res) showReservationModal(res);
    });
  });
}

// ============================================================
// REFRESH — re-render only the calendar body, keep page shell
// ============================================================
function refreshView(container) {
  const calView = container.querySelector('#cal-view');
  if (!calView) {
    // Fallback: full re-render
    render(container);
    return;
  }

  const isMobile = window.innerWidth <= 768;
  calView.innerHTML = isMobile ? buildMobileView() : buildDesktopView();

  lucide.createIcons();
  bindEvents(container);
  scrollToToday(container);
}

// ============================================================
// SCROLL TO TODAY'S COLUMN (desktop only)
// ============================================================
function scrollToToday(container) {
  requestAnimationFrame(() => {
    const scroll = container.querySelector('#cal-scroll');
    if (!scroll) return;

    // If viewing the current month, center on today's column
    const now = new Date();
    if (viewYear === now.getFullYear() && viewMonth === now.getMonth()) {
      const todayLeft = (now.getDate() - 1) * CELL_W;
      const viewW     = scroll.clientWidth;
      scroll.scrollLeft = Math.max(0, todayLeft - viewW / 3);
    } else {
      // Otherwise scroll to the start
      scroll.scrollLeft = 0;
    }
  });
}

// ============================================================
// MAIN EXPORT
// ============================================================
export function render(container) {
  initDate();
  injectStyles();

  const isMobile = window.innerWidth <= 768;

  container.innerHTML = `
    <div class="page-enter">
      <div class="page-header">
        <div class="page-header-left">
          <h1>Calendar</h1>
          <p>Room booking calendar</p>
        </div>
      </div>

      <div id="cal-view">
        ${isMobile ? buildMobileView() : buildDesktopView()}
      </div>
    </div>`;

  lucide.createIcons();
  bindEvents(container);
  scrollToToday(container);
}