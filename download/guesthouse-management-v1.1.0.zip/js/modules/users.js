/**
 * users.js — User Management Module
 */
import { Users, Auth, Activity } from '../data.js';
import { t, formatDate } from '../i18n.js';
import { openModal, closeModal, showToast, showConfirm, escHtml } from '../app.js';

export function render(container) {
  container.innerHTML = buildPage();
  lucide.createIcons();
  bindEvents(container);
}

function buildPage() {
  const allUsers = Users.getAll();
  const currentUser = Auth.getCurrentUser();
  const superuserCount = allUsers.filter(u => u.role === 'superuser').length;
  const operatorCount = allUsers.filter(u => u.role === 'operator').length;

  return `
  <div class="page-enter">
    <div class="page-header">
      <div class="page-header-left">
        <h1>${t('user.title')}</h1>
        <p>${t('user.subtitle')}</p>
      </div>
      <div class="page-header-actions">
        <button class="btn btn-primary" id="add-user-btn">
          <i data-lucide="user-plus"></i> ${t('user.add')}
        </button>
      </div>
    </div>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
      <div class="stat-card stat-blue">
        <div class="stat-icon"><i data-lucide="users"></i></div>
        <div class="stat-value">${allUsers.length}</div>
        <div class="stat-label">Total Users</div>
      </div>
      <div class="stat-card stat-gold">
        <div class="stat-icon"><i data-lucide="shield-check"></i></div>
        <div class="stat-value">${superuserCount}</div>
        <div class="stat-label">Superusers</div>
      </div>
      <div class="stat-card stat-green">
        <div class="stat-icon"><i data-lucide="user-cog"></i></div>
        <div class="stat-value">${operatorCount}</div>
        <div class="stat-label">Operators</div>
      </div>
    </div>

    <!-- Users Table -->
    ${allUsers.length === 0
      ? `<div class="empty-state">
           <div class="empty-icon"><i data-lucide="users"></i></div>
           <h3>${t('user.no_users')}</h3>
           <p>${t('user.add_first')}</p>
           <button class="btn btn-primary" style="margin-top:16px" id="add-user-empty">
             <i data-lucide="user-plus"></i> ${t('user.add')}
           </button>
         </div>`
      : `<div class="card">
           <div class="card-header">
             <div class="card-title">${allUsers.length} ${t('user.users_label')}</div>
           </div>
           <div class="table-wrapper">
             <table class="data-table">
               <thead>
                 <tr>
                   <th>${t('user.username')}</th>
                   <th>${t('user.full_name')}</th>
                   <th>${t('user.role')}</th>
                   <th>${t('common.date')}</th>
                   <th>${t('common.actions')}</th>
                 </tr>
               </thead>
               <tbody>
                 ${allUsers.map(u => userRow(u, currentUser)).join('')}
               </tbody>
             </table>
           </div>
         </div>`
    }
  </div>`;
}

function userRow(u, currentUser) {
  const isSelf = currentUser && currentUser.id === u.id;
  return `
  <tr>
    <td>
      <div style="display:flex;align-items:center;gap:10px">
        <div class="guest-avatar">${getInitials(u.name)}</div>
        <div>
          <div style="font-weight:600">${escHtml(u.username)}</div>
          ${isSelf ? `<div style="font-size:11px;color:var(--gold);font-weight:600">You</div>` : ''}
        </div>
      </div>
    </td>
    <td>${escHtml(u.name)}</td>
    <td>
      <span class="badge ${u.role === 'superuser' ? 'badge-gold' : 'badge-blue'}">
        ${u.role === 'superuser' ? 'Superuser' : 'Operator'}
      </span>
    </td>
    <td style="color:var(--text-secondary);font-size:12px">${formatDate(u.createdAt)}</td>
    <td>
      <div class="actions-cell">
        <button class="btn btn-sm btn-ghost edit-user-btn" data-id="${u.id}" title="${t('common.edit')}">
          <i data-lucide="pencil"></i>
        </button>
        <button class="btn btn-sm btn-secondary change-password-btn" data-id="${u.id}" title="Change Password">
          <i data-lucide="key-round"></i>
        </button>
        ${!isSelf ? `
        <button class="btn btn-sm btn-danger delete-user-btn" data-id="${u.id}" title="${t('common.delete')}">
          <i data-lucide="trash-2"></i>
        </button>` : ''}
      </div>
    </td>
  </tr>`;
}

function bindEvents(container) {
  container.addEventListener('click', e => {
    const btn = e.target.closest('button');
    if (!btn) return;

    if (btn.id === 'add-user-btn' || btn.id === 'add-user-empty') {
      openUserForm(container);
    } else if (btn.classList.contains('edit-user-btn')) {
      openUserForm(container, btn.dataset.id);
    } else if (btn.classList.contains('change-password-btn')) {
      openChangePassword(container, btn.dataset.id);
    } else if (btn.classList.contains('delete-user-btn')) {
      handleDelete(container, btn.dataset.id);
    }
  });
}

function openUserForm(container, id = null) {
  const u = id ? Users.getById(id) : null;

  // Check for duplicate username
  openModal(u ? t('user.edit') : t('user.add'), `
    <form id="user-form" class="form-grid">
      <div class="form-group">
        <label>${t('user.username')} *</label>
        <input class="form-input" name="username" value="${escHtml(u?.username || '')}" required placeholder="e.g. john" ${u ? 'readonly style="opacity:.6;cursor:not-allowed"' : ''}>
        ${u ? '<span class="form-help">Username cannot be changed</span>' : ''}
      </div>
      <div class="form-group">
        <label>${t('user.full_name')} *</label>
        <input class="form-input" name="name" value="${escHtml(u?.name || '')}" required placeholder="Full name">
      </div>
      <div class="form-group">
        <label>${u ? t('user.password_optional') : t('user.password')} *</label>
        <input class="form-input" name="password" type="password" ${u ? '' : 'required'} placeholder="${u ? 'Leave blank to keep current' : 'Password'}">
      </div>
      <div class="form-group">
        <label>${t('user.role')} *</label>
        <select class="form-select" name="role" required>
          <option value="superuser" ${u?.role === 'superuser' ? 'selected' : ''}>Superuser</option>
          <option value="operator"  ${u?.role === 'operator' ? 'selected' : ''}>Operator</option>
        </select>
      </div>
      <div class="form-actions span-2">
        <button type="button" class="btn btn-ghost" id="cancel-user">${t('common.cancel')}</button>
        <button type="submit" class="btn btn-primary">${t('common.save')}</button>
      </div>
    </form>
  `);

  document.getElementById('cancel-user')?.addEventListener('click', closeModal);

  document.getElementById('user-form').addEventListener('submit', e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd);

    if (u) {
      // Edit mode — skip password if blank
      if (!data.password) delete data.password;
      Users.update(id, data);
      Activity.log(`User updated: ${data.username}`, 'info');
      showToast('User updated', `${data.name} updated successfully`, 'success');
    } else {
      // Add mode — check duplicate username
      if (Users.getByUsername(data.username)) {
        showToast('Duplicate Username', `A user with username "${data.username}" already exists.`, 'error');
        return;
      }
      Users.add(data);
      Activity.log(`User created: ${data.username} (${data.role})`, 'info');
      showToast('User created', `${data.name} has been added successfully`, 'success');
    }
    closeModal();
    render(container);
  });
}

function openChangePassword(container, id) {
  const u = Users.getById(id);
  if (!u) return;

  openModal(`Change Password — ${escHtml(u.username)}`, `
    <form id="password-form" class="form-grid">
      <div class="form-group span-2">
        <label>Current Password *</label>
        <input class="form-input" name="currentPassword" type="password" required placeholder="Enter current password" autocomplete="current-password">
      </div>
      <div class="form-group">
        <label>New Password *</label>
        <input class="form-input" name="newPassword" type="password" required placeholder="Enter new password" autocomplete="new-password">
      </div>
      <div class="form-group">
        <label>Confirm New Password *</label>
        <input class="form-input" name="confirmPassword" type="password" required placeholder="Confirm new password" autocomplete="new-password">
      </div>
      <div class="form-actions span-2">
        <button type="button" class="btn btn-ghost" id="cancel-password">${t('common.cancel')}</button>
        <button type="submit" class="btn btn-primary">Change Password</button>
      </div>
    </form>
  `);

  document.getElementById('cancel-password')?.addEventListener('click', closeModal);

  document.getElementById('password-form').addEventListener('submit', e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const { currentPassword, newPassword, confirmPassword } = Object.fromEntries(fd);

    // Validate current password
    if (u.password !== currentPassword) {
      showToast('Incorrect Password', 'The current password you entered is incorrect.', 'error');
      return;
    }

    // Validate new passwords match
    if (newPassword !== confirmPassword) {
      showToast('Password Mismatch', 'New password and confirmation do not match.', 'error');
      return;
    }

    // Validate new password is not empty
    if (!newPassword.trim()) {
      showToast('Invalid Password', 'New password cannot be empty.', 'error');
      return;
    }

    Users.update(id, { password: newPassword });
    Activity.log(`Password changed for user: ${u.username}`, 'info');
    showToast('Password Changed', `Password for ${u.name} has been updated.`, 'success');
    closeModal();
  });
}

function handleDelete(container, id) {
  const currentUser = Auth.getCurrentUser();
  const u = Users.getById(id);

  // Prevent deleting yourself
  if (currentUser && currentUser.id === id) {
    showToast('Cannot Delete', 'You cannot delete your own account.', 'error');
    return;
  }

  if (!u) return;

  showConfirm(
    `Delete User "${u.username}"?`,
    `This will permanently remove ${escHtml(u.name)} (${escHtml(u.username)}) from the system. ${t('common.delete_confirm')}`,
    () => {
      Users.delete(id);
      Activity.log(`User deleted: ${u.username}`, 'warning');
      showToast('User deleted', `${u.name} has been removed.`, 'success');
      render(container);
    }
  );
}

// Helpers
function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
}