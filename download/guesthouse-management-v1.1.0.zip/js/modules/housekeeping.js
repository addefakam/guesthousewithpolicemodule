/**
 * housekeeping.js — Housekeeping Management Module
 */
import { Housekeeping, Rooms } from '../data.js';
import { t, formatDate, formatDateTime } from '../i18n.js';
import { openModal, closeModal, showToast, showConfirm, escHtml } from '../app.js';

let filterStatus = 'all';
let filterDate = new Date().toISOString().slice(0,10);

export function render(container) {
  container.innerHTML = buildPage();
  lucide.createIcons();
  bindEvents(container);
}

function buildPage() {
  const stats = Housekeeping.getStats();
  const tasks = getFiltered();
  const rooms = Rooms.getAll();
  const sorted = [...tasks].sort((a,b) => {
    if (a.status === 'in_progress' && b.status !== 'in_progress') return -1;
    if (b.status === 'in_progress' && a.status !== 'in_progress') return 1;
    if (a.status === 'pending' && b.status === 'completed') return -1;
    if (b.status === 'pending' && a.status === 'completed') return 1;
    return b.createdAt?.localeCompare(a.createdAt);
  });

  return `
  <div class="page-enter">
    <div class="page-header">
      <div class="page-header-left">
        <h1>${t('hk.title')}</h1>
        <p>${t('hk.subtitle')}</p>
      </div>
      <div class="page-header-actions">
        <button class="btn btn-primary" id="add-task-btn">
          <i data-lucide="plus"></i> ${t('hk.add_task')}
        </button>
      </div>
    </div>

    <div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
      <div class="stat-card stat-blue">
        <div class="stat-icon"><i data-lucide="list"></i></div>
        <div class="stat-value">${stats.total}</div>
        <div class="stat-label">Total Tasks</div>
      </div>
      <div class="stat-card stat-orange">
        <div class="stat-icon"><i data-lucide="clock"></i></div>
        <div class="stat-value">${stats.pending}</div>
        <div class="stat-label">Pending</div>
      </div>
      <div class="stat-card stat-gold">
        <div class="stat-icon"><i data-lucide="loader"></i></div>
        <div class="stat-value">${stats.in_progress}</div>
        <div class="stat-label">In Progress</div>
      </div>
      <div class="stat-card stat-green">
        <div class="stat-icon"><i data-lucide="check-circle"></i></div>
        <div class="stat-value">${stats.completed}</div>
        <div class="stat-label">Completed</div>
      </div>
    </div>

    <div class="filter-bar" style="margin-bottom:20px">
      <div class="search-bar" style="flex:unset;max-width:160px">
        <i data-lucide="calendar"></i>
        <input class="search-input" type="date" id="hk-date-filter" value="${filterDate}">
      </div>
      <button class="filter-btn ${filterStatus==='all'?'active':''}" data-filter="all">All</button>
      <button class="filter-btn ${filterStatus==='pending'?'active':''}" data-filter="pending">Pending</button>
      <button class="filter-btn ${filterStatus==='in_progress'?'active':''}" data-filter="in_progress">In Progress</button>
      <button class="filter-btn ${filterStatus==='completed'?'active':''}" data-filter="completed">Completed</button>
    </div>

    ${sorted.length === 0
      ? `<div class="empty-state">
           <div class="empty-icon"><i data-lucide="sparkles"></i></div>
           <h3>${t('hk.no_tasks')}</h3>
           <p>${t('hk.add_first')}</p>
           <button class="btn btn-primary" style="margin-top:16px" id="add-task-empty">
             <i data-lucide="plus"></i> ${t('hk.add_task')}
           </button>
         </div>`
      : `<div class="card">
           <div class="table-wrapper">
             <table class="data-table">
               <thead>
                 <tr>
                   <th>Room</th>
                   <th>Type</th>
                   <th>Assigned To</th>
                   <th>Date</th>
                   <th>Status</th>
                   <th>Notes</th>
                   <th>Actions</th>
                 </tr>
               </thead>
               <tbody>
                 ${sorted.map(taskRow).join('')}
               </tbody>
             </table>
           </div>
         </div>`
    }
  </div>`;
}

function getFiltered() {
  let tasks = Housekeeping.getAll();
  if (filterDate) {
    tasks = tasks.filter(t => t.scheduledDate === filterDate);
  }
  if (filterStatus !== 'all') {
    tasks = tasks.filter(t => t.status === filterStatus);
  }
  return tasks;
}

function taskRow(task) {
  const room = Rooms.getById(task.roomId);
  const statusBadge = {
    pending: '<span class="badge badge-pending">Pending</span>',
    in_progress: '<span class="badge badge-active">In Progress</span>',
    completed: '<span class="badge badge-completed">Completed</span>',
  };
  const typeLabel = {
    cleaning: 'Cleaning',
    maintenance: 'Maintenance',
    inspection: 'Inspection',
    deep_clean: 'Deep Clean',
  };

  return `
  <tr>
    <td><strong style="color:var(--gold)">Room ${escHtml(room?.number || '?')}</strong></td>
    <td><span class="tag">${escHtml(typeLabel[task.type] || task.type)}</span></td>
    <td>${escHtml(task.assignedTo || '—')}</td>
    <td style="font-size:12px">${formatDate(task.scheduledDate)}</td>
    <td>${statusBadge[task.status] || task.status}</td>
    <td style="font-size:12px;color:var(--text-secondary);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(task.notes || '—')}</td>
    <td>
      <div class="actions-cell">
        ${task.status === 'pending' ? `<button class="btn btn-sm btn-success start-task-btn" data-id="${task.id}" title="Start"><i data-lucide="play"></i></button>` : ''}
        ${task.status === 'in_progress' ? `<button class="btn btn-sm btn-primary complete-task-btn" data-id="${task.id}" title="Complete"><i data-lucide="check"></i></button>` : ''}
        <button class="btn btn-sm btn-ghost edit-task-btn" data-id="${task.id}" title="Edit"><i data-lucide="pencil"></i></button>
        <button class="btn btn-sm btn-danger delete-task-btn" data-id="${task.id}" title="Delete"><i data-lucide="trash-2"></i></button>
      </div>
    </td>
  </tr>`;
}

function bindEvents(container) {
  container.querySelector('#hk-date-filter')?.addEventListener('change', e => {
    filterDate = e.target.value;
    render(container);
  });

  container.addEventListener('click', e => {
    const btn = e.target.closest('button, [data-filter]');
    if (!btn) return;

    if (btn.id === 'add-task-btn' || btn.id === 'add-task-empty') {
      openTaskForm(container);
    } else if (btn.dataset.filter !== undefined) {
      filterStatus = btn.dataset.filter;
      render(container);
    } else if (btn.classList.contains('start-task-btn')) {
      Housekeeping.update(btn.dataset.id, { status: 'in_progress' });
      showToast('Task started', '', 'success');
      render(container);
    } else if (btn.classList.contains('complete-task-btn')) {
      Housekeeping.update(btn.dataset.id, { status: 'completed', completedAt: new Date().toISOString() });
      showToast('Task completed', '', 'success');
      render(container);
    } else if (btn.classList.contains('edit-task-btn')) {
      openTaskForm(container, btn.dataset.id);
    } else if (btn.classList.contains('delete-task-btn')) {
      showConfirm('Delete task?', t('common.delete_confirm'), () => {
        Housekeeping.delete(btn.dataset.id);
        showToast('Task deleted', '', 'success');
        render(container);
      });
    }
  });
}

function openTaskForm(container, id = null) {
  const task = id ? Housekeeping.getById(id) : null;
  const rooms = Rooms.getAll();
  const today = new Date().toISOString().slice(0,10);

  openModal(task ? 'Edit Task' : t('hk.add_task'), `
    <form id="task-form" class="form-grid">
      <div class="form-group">
        <label>Room *</label>
        <select class="form-select" name="roomId" required>
          <option value="">— Select Room —</option>
          ${rooms.map(r => `<option value="${r.id}" ${task?.roomId===r.id?'selected':''}>Room ${escHtml(r.number)} (${r.type})</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Task Type *</label>
        <select class="form-select" name="type" required>
          <option value="cleaning" ${task?.type==='cleaning'?'selected':''}>Cleaning</option>
          <option value="deep_clean" ${task?.type==='deep_clean'?'selected':''}>Deep Clean</option>
          <option value="maintenance" ${task?.type==='maintenance'?'selected':''}>Maintenance</option>
          <option value="inspection" ${task?.type==='inspection'?'selected':''}>Inspection</option>
        </select>
      </div>
      <div class="form-group">
        <label>Assigned To</label>
        <input class="form-input" name="assignedTo" value="${task?.assignedTo||''}" placeholder="Staff name">
      </div>
      <div class="form-group">
        <label>Date *</label>
        <input class="form-input" name="scheduledDate" type="date" value="${task?.scheduledDate||today}" required>
      </div>
      <div class="form-group span-2">
        <label>Notes</label>
        <textarea class="form-textarea" name="notes" placeholder="Task details...">${task?.notes||''}</textarea>
      </div>
      <div class="form-actions span-2">
        <button type="button" class="btn btn-ghost" id="cancel-task">Cancel</button>
        <button type="submit" class="btn btn-primary">${t('common.save')}</button>
      </div>
    </form>
  `);

  document.getElementById('cancel-task')?.addEventListener('click', closeModal);
  document.getElementById('task-form').addEventListener('submit', e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    if (task) {
      Housekeeping.update(id, data);
      showToast('Task updated', '', 'success');
    } else {
      Housekeeping.addTask(data);
      showToast('Task created', '', 'success');
    }
    closeModal();
    render(container);
  });
}