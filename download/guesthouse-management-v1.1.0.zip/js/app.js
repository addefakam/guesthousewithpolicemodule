/**
 * app.js — Main Application Entry Point
 * Guest House Management System
 */
import { setLanguage, getLang, applyTranslations, t } from './i18n.js';
import { Settings, seedDemoData, Auth, Reservations, Rooms, Guests, Resources, Activity } from './data.js';

// ---- Module registry (lazy loaded) ----
const modules = {
  dashboard:    () => import('./modules/dashboard.js'),
  rooms:        () => import('./modules/rooms.js'),
  guests:       () => import('./modules/guests.js'),
  reservations: () => import('./modules/reservations.js'),
  calendar:     () => import('./modules/calendar.js'),
  daytime:      () => import('./modules/daytime.js'),
  expenses:     () => import('./modules/expenses.js'),
  resources:    () => import('./modules/resources.js'),
  reports:      () => import('./modules/reports.js'),
  housekeeping: () => import('./modules/housekeeping.js'),
  'activity-log':() => import('./modules/activity-log.js'),
  users:        () => import('./modules/users.js'),
  settings:     () => import('./modules/settings.js'),
};

let currentPage = 'dashboard';
let notifPanelOpen = false;

// ============================================================
// BOOT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  // Seed demo data on first run
  seedDemoData();

  // Load settings
  const settings = Settings.get();
  const lang = settings.language || 'en';
  setLanguage(lang);

  // Apply settings to UI
  applySettingsToUI(settings);

  // Set current date
  updateDateDisplay();

  // Initialize Lucide icons
  lucide.createIcons();

  // Sidebar events
  initSidebar();

  // Language switcher
  initLangSwitcher(lang);

  // Modal events
  initModal();

  // Confirm dialog
  initConfirmDialog();

  // Navigate to dashboard
  // Expose navigate globally for quick-action buttons
  window.navigate = navigate;

  // Initialize Authentication
  initAuth();

  // Initialize Notifications
  initNotifications();

  // Keyboard shortcuts
  initKeyboardShortcuts();
});

// ============================================================
// NOTIFICATION SYSTEM
// ============================================================
function getNotifications() {
  const alerts = [];
  const today = new Date().toISOString().slice(0,10);

  // Today's check-ins (upcoming)
  const todayCI = Reservations.getTodayCheckIns().filter(r => r.status === 'upcoming');
  todayCI.forEach(r => {
    const guest = Guests.getById(r.guestId);
    const room = Rooms.getById(r.roomId);
    alerts.push({
      id: `ci-${r.id}`,
      type: 'info',
      icon: 'log-in',
      title: 'Check-in Today',
      message: `${guest?.name || 'Guest'} — Room ${room?.number || '?'}`,
      time: r.checkIn,
    });
  });

  // Today's check-outs
  const todayCO = Reservations.getTodayCheckOuts();
  todayCO.forEach(r => {
    const guest = Guests.getById(r.guestId);
    const room = Rooms.getById(r.roomId);
    alerts.push({
      id: `co-${r.id}`,
      type: 'warning',
      icon: 'log-out',
      title: 'Check-out Today',
      message: `${guest?.name || 'Guest'} — Room ${room?.number || '?'}`,
      time: r.checkOut,
    });
  });

  // Pending payments
  const pendingPay = Reservations.getPendingPayments();
  pendingPay.forEach(r => {
    const guest = Guests.getById(r.guestId);
    const balance = (parseFloat(r.totalCost)||0) - (parseFloat(r.paidAmount)||0);
    if (balance > 0.01) {
      alerts.push({
        id: `pay-${r.id}`,
        type: 'danger',
        icon: 'alert-circle',
        title: 'Pending Payment',
        message: `${guest?.name || 'Guest'} — ${balance.toFixed(2)} ETB due`,
        time: r.createdAt,
      });
    }
  });

  // Low stock
  const lowStock = Resources.getLowStock();
  lowStock.forEach(r => {
    alerts.push({
      id: `stock-${r.id}`,
      type: 'warning',
      icon: 'package-x',
      title: 'Low Stock',
      message: `${r.name}: ${r.quantity} ${r.unit || 'units'} remaining`,
      time: r.updatedAt || r.createdAt,
    });
  });

  // Overdue check-outs (active reservations past checkout date)
  const activeRes = Reservations.getActive();
  activeRes.forEach(r => {
    if (r.checkOut && r.checkOut < today) {
      const guest = Guests.getById(r.guestId);
      const room = Rooms.getById(r.roomId);
      const overdueDays = Math.ceil((new Date(today) - new Date(r.checkOut)) / (1000*60*60*24));
      alerts.push({
        id: `overdue-${r.id}`,
        type: 'danger',
        icon: 'alert-triangle',
        title: 'Overdue Check-out',
        message: `${guest?.name || 'Guest'} — Room ${room?.number || '?'} (${overdueDays}d overdue)`,
        time: r.checkOut,
      });
    }
  });

  return alerts;
}

function initNotifications() {
  const bell = document.getElementById('notification-bell');
  const badge = document.getElementById('notification-badge');

  // Create notification panel
  const panel = document.createElement('div');
  panel.id = 'notification-panel';
  panel.className = 'notif-panel hidden';
  panel.innerHTML = `
    <div class="notif-panel-header">
      <h3>Notifications</h3>
      <button id="notif-close" class="icon-btn" style="width:28px;height:28px"><i data-lucide="x" style="width:14px;height:14px"></i></button>
    </div>
    <div id="notif-list" class="notif-list"></div>
    <div id="notif-empty" class="notif-empty" style="display:none;padding:24px;text-align:center;color:var(--text-muted)">
      <i data-lucide="bell-off" style="width:24px;height:24px;margin-bottom:8px;opacity:.5"></i>
      <p>No new notifications</p>
    </div>
  `;
  document.body.appendChild(panel);

  function refreshBadge() {
    const count = getNotifications().length;
    if (count > 0) {
      badge.textContent = count > 9 ? '9+' : count;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  }

  function renderNotifs() {
    const notifs = getNotifications();
    const list = document.getElementById('notif-list');
    const empty = document.getElementById('notif-empty');
    if (notifs.length === 0) {
      list.style.display = 'none';
      empty.style.display = 'block';
    } else {
      list.style.display = 'block';
      empty.style.display = 'none';
      list.innerHTML = notifs.map(n => {
        const colorMap = { info: 'var(--blue)', warning: 'var(--orange)', danger: 'var(--red)' };
        const bgColorMap = { info: 'var(--blue-dim)', warning: 'var(--orange-dim)', danger: 'var(--red-dim)' };
        return `
        <div class="notif-item" style="border-left:3px solid ${colorMap[n.type] || 'var(--border)'}">
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:${bgColorMap[n.type] || 'var(--bg-elevated)'};color:${colorMap[n.type] || 'var(--text-secondary)'};flex-shrink:0">
              <i data-lucide="${n.icon}" style="width:16px;height:16px"></i>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:12px;font-weight:700;color:var(--text-primary)">${escHtml(n.title)}</div>
              <div style="font-size:11px;color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(n.message)}</div>
            </div>
          </div>
        </div>`;
      }).join('');
    }
    lucide.createIcons();
  }

  bell?.addEventListener('click', (e) => {
    e.stopPropagation();
    notifPanelOpen = !notifPanelOpen;
    panel.classList.toggle('hidden', !notifPanelOpen);
    if (notifPanelOpen) renderNotifs();
  });

  document.getElementById('notif-close')?.addEventListener('click', () => {
    notifPanelOpen = false;
    panel.classList.add('hidden');
  });

  document.addEventListener('click', (e) => {
    if (notifPanelOpen && !panel.contains(e.target) && e.target !== bell && !bell?.contains(e.target)) {
      notifPanelOpen = false;
      panel.classList.add('hidden');
    }
  });

  // Refresh badge periodically
  refreshBadge();
  setInterval(refreshBadge, 30000);
}

// ============================================================
// KEYBOARD SHORTCUTS
// ============================================================
function initKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Don't trigger in input/textarea
    if (['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)) return;
    // Don't trigger when modal is open
    if (!document.getElementById('modal-overlay')?.classList.contains('hidden')) return;

    const ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && e.key === '1') { e.preventDefault(); navigate('dashboard'); }
    else if (ctrl && e.key === '2') { e.preventDefault(); navigate('rooms'); }
    else if (ctrl && e.key === '3') { e.preventDefault(); navigate('reservations'); }
    else if (ctrl && e.key === '4') { e.preventDefault(); navigate('guests'); }
    else if (ctrl && e.key === '5') { e.preventDefault(); navigate('calendar'); }
    else if (ctrl && e.key === '6') { e.preventDefault(); navigate('daytime'); }
    else if (ctrl && e.key === '7') { e.preventDefault(); navigate('expenses'); }
    else if (e.key === 'n' && ctrl) { e.preventDefault(); navigate('reservations'); setTimeout(() => document.querySelector('#add-res-btn, #add-res-empty')?.click(), 300); }
    else if (e.key === 'g' && ctrl) { e.preventDefault(); navigate('guests'); setTimeout(() => document.querySelector('#add-guest-btn, #add-guest-empty')?.click(), 300); }
    else if (e.key === '?' && !ctrl) {
      e.preventDefault();
      openModal('Keyboard Shortcuts', `
        <div style="display:grid;grid-template-columns:auto 1fr;gap:8px 16px;font-size:13px">
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+1</kbd><span style="color:var(--text-secondary)">Dashboard</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+2</kbd><span style="color:var(--text-secondary)">Rooms</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+3</kbd><span style="color:var(--text-secondary)">Reservations</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+4</kbd><span style="color:var(--text-secondary)">Guests</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+5</kbd><span style="color:var(--text-secondary)">Calendar</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+6</kbd><span style="color:var(--text-secondary)">Daytime Services</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+7</kbd><span style="color:var(--text-secondary)">Expenses</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+N</kbd><span style="color:var(--text-secondary)">New Reservation</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">Ctrl+G</kbd><span style="color:var(--text-secondary)">New Guest</span>
          <kbd style="background:var(--bg-elevated);padding:2px 8px;border-radius:4px;font-family:monospace;color:var(--gold);border:1px solid var(--border)">?</kbd><span style="color:var(--text-secondary)">Show Shortcuts</span>
        </div>
        <div class="form-actions" style="margin-top:16px">
          <button type="button" class="btn btn-ghost" id="close-shortcuts">Close</button>
        </div>
      `);
      document.getElementById('close-shortcuts')?.addEventListener('click', closeModal);
      lucide.createIcons();
    }
  });
}

// ============================================================
// AUTHENTICATION
// ============================================================
function initAuth() {
  const loginOverlay = document.getElementById('login-overlay');
  const loginForm = document.getElementById('login-form');
  const logoutBtn = document.getElementById('logout-btn');

  function updateAuthState() {
    const user = Auth.getCurrentUser();
    if (!user) {
      loginOverlay.classList.remove('hidden');
      document.getElementById('sidebar').style.display = 'none';
      document.querySelector('.top-bar').style.display = 'none';
    } else {
      loginOverlay.classList.add('hidden');
      document.getElementById('sidebar').style.display = 'flex';
      document.querySelector('.top-bar').style.display = 'flex';
      applyRoleUI(user);
      navigate('dashboard');
    }
  }

  function applyRoleUI(user) {
    // Set Owner/User details
    const ownerDisplay = document.getElementById('owner-name-display');
    const ownerRole = document.getElementById('owner-role-display');
    if (ownerDisplay) ownerDisplay.textContent = user.name || user.username;
    if (ownerRole) ownerRole.textContent = user.role.toUpperCase();

    // Toggle navigation based on role
    document.querySelectorAll('.nav-item').forEach(item => {
      const roleReq = item.getAttribute('data-role');
      if (roleReq && user.role !== roleReq) {
        item.style.display = 'none';
      } else {
        item.style.display = 'flex';
      }
    });
  }

  loginForm?.addEventListener('submit', e => {
    e.preventDefault();
    const userEl = document.getElementById('login-username');
    const passEl = document.getElementById('login-password');
    if (Auth.login(userEl.value, passEl.value)) {
      showToast('Success', 'Logged in successfully', 'success');
      updateAuthState();
      loginForm.reset();
    } else {
      showToast('Error', 'Invalid username or password', 'error');
    }
  });

  logoutBtn?.addEventListener('click', () => {
    Auth.logout();
    updateAuthState();
  });

  updateAuthState();
}

// ============================================================
// NAVIGATION
// ============================================================
async function navigate(page) {
  const user = Auth.getCurrentUser();
  if (!user) return; // Prevent navigation if not logged in

  const targetNav = document.querySelector(`.nav-item[data-page="${page}"]`);
  const reqRole = targetNav?.getAttribute('data-role');
  if (reqRole && user.role !== reqRole) {
    showToast('Access Denied', 'You do not have permission to view this page.', 'error');
    return;
  }

  currentPage = page;

  // Update sidebar active
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.page === page);
  });

  // Update breadcrumb
  const pageTitle = document.getElementById('page-title');
  if (pageTitle) {
    const key = `nav.${page}`;
    pageTitle.textContent = t(key);
    pageTitle.setAttribute('data-i18n', key);
  }

  // Show loading
  const content = document.getElementById('page-content');
  content.innerHTML = `<div class="init-loader"><div class="spinner-ring"></div><p>${t('common.loading')}</p></div>`;

  // Load and render module
  try {
    const mod = await modules[page]();
    // Small delay for visual polish
    await new Promise(r => setTimeout(r, 100));
    mod.render(content);
  } catch (err) {
    console.error(`Failed to load module: ${page}`, err);
    content.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon"><i data-lucide="alert-circle"></i></div>
        <h3>Failed to load page</h3>
        <p style="color:var(--red)">${err.message}</p>
        <button class="btn btn-primary" style="margin-top:16px" onclick="navigate('dashboard')">
          <i data-lucide="home"></i> Go to Dashboard
        </button>
      </div>`;
    lucide.createIcons();
  }

  // Close mobile sidebar
  document.getElementById('sidebar')?.classList.remove('mobile-open');
}

window.navigate = navigate;

// ============================================================
// SIDEBAR
// ============================================================
function initSidebar() {
  // Nav item clicks
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', e => {
      e.preventDefault();
      const page = item.dataset.page;
      if (page) navigate(page);
    });
  });

  // Toggle collapse/expand
  const toggleBtn = document.getElementById('sidebar-toggle');
  const sidebar   = document.getElementById('sidebar');
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      // On mobile: toggle mobile-open; on desktop: toggle collapsed
      if (window.innerWidth <= 900) {
        sidebar.classList.toggle('mobile-open');
      } else {
        sidebar.classList.toggle('collapsed');
      }
    });
  }

  // Close mobile sidebar on outside click
  document.addEventListener('click', e => {
    if (window.innerWidth <= 900 && sidebar?.classList.contains('mobile-open')) {
      if (!sidebar.contains(e.target) && e.target !== toggleBtn && !toggleBtn?.contains(e.target)) {
        sidebar.classList.remove('mobile-open');
      }
    }
  });
}

// ============================================================
// LANGUAGE SWITCHER
// ============================================================
function initLangSwitcher(initialLang) {
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === initialLang);
    btn.addEventListener('click', () => {
      const lang = btn.dataset.lang;
      setLanguage(lang);
      Settings.update({ language: lang });
      document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // Re-render current page with new translations
      navigate(currentPage);
    });
  });
}

// ============================================================
// MODAL
// ============================================================
let modalResolve = null;

function initModal() {
  const overlay  = document.getElementById('modal-overlay');
  const closeBtn = document.getElementById('modal-close-btn');

  closeBtn?.addEventListener('click', closeModal);
  overlay?.addEventListener('click', e => {
    if (e.target === overlay) closeModal();
  });

  // Escape key
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if (!document.getElementById('modal-overlay')?.classList.contains('hidden')) {
        closeModal();
      }
      if (!document.getElementById('confirm-overlay')?.classList.contains('hidden')) {
        document.getElementById('confirm-overlay')?.classList.add('hidden');
      }
    }
  });
}

export function openModal(title, bodyHtml) {
  const overlay = document.getElementById('modal-overlay');
  const titleEl = document.getElementById('modal-title');
  const bodyEl  = document.getElementById('modal-body');

  if (titleEl) titleEl.textContent = title;
  if (bodyEl)  bodyEl.innerHTML = bodyHtml;
  overlay?.classList.remove('hidden');
  lucide.createIcons();

  // Focus first input
  setTimeout(() => {
    const firstInput = bodyEl?.querySelector('input:not([type=hidden]),select,textarea');
    firstInput?.focus();
  }, 100);
}

export function closeModal() {
  document.getElementById('modal-overlay')?.classList.add('hidden');
  const bodyEl = document.getElementById('modal-body');
  if (bodyEl) bodyEl.innerHTML = '';
}

// ============================================================
// CONFIRM DIALOG
// ============================================================
let confirmCallback = null;

function initConfirmDialog() {
  const cancelBtn = document.getElementById('confirm-cancel-btn');
  const okBtn     = document.getElementById('confirm-ok-btn');
  const overlay   = document.getElementById('confirm-overlay');

  cancelBtn?.addEventListener('click', () => {
    overlay?.classList.add('hidden');
    confirmCallback = null;
  });

  okBtn?.addEventListener('click', () => {
    overlay?.classList.add('hidden');
    if (confirmCallback) confirmCallback();
    confirmCallback = null;
  });

  overlay?.addEventListener('click', e => {
    if (e.target === overlay) {
      overlay.classList.add('hidden');
      confirmCallback = null;
    }
  });
}

export function showConfirm(title, message, onConfirm) {
  const overlay  = document.getElementById('confirm-overlay');
  const titleEl  = document.getElementById('confirm-title-text');
  const msgEl    = document.getElementById('confirm-msg-text');

  if (titleEl) titleEl.textContent = title;
  if (msgEl)   msgEl.textContent   = message;
  confirmCallback = onConfirm;
  overlay?.classList.remove('hidden');
}

// ============================================================
// TOAST
// ============================================================
export function showToast(title, message = '', type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const iconMap = {
    success: 'check-circle',
    error:   'x-circle',
    warning: 'alert-triangle',
    info:    'info',
  };

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-icon"><i data-lucide="${iconMap[type] || 'info'}"></i></div>
    <div class="toast-content">
      <div class="toast-title">${escHtml(title)}</div>
      ${message ? `<div class="toast-msg">${escHtml(message)}</div>` : ''}
    </div>
  `;

  container.appendChild(toast);
  lucide.createIcons();

  // Auto-remove after 4 seconds
  setTimeout(() => {
    toast.style.animation = 'toastOut 0.3s ease forwards';
    setTimeout(() => toast.remove(), 350);
  }, 4000);
}

// ============================================================
// HELPERS
// ============================================================
function applySettingsToUI(settings) {
  // Brand name
  const brandName = document.getElementById('sidebar-house-name');
  if (brandName) brandName.textContent = settings.guestHouseName || 'GuestHouse';

  // Owner info
  const ownerDisplay = document.getElementById('owner-name-display');
  if (ownerDisplay) ownerDisplay.textContent = settings.ownerName || 'Owner';

  const ownerAvatar = document.getElementById('owner-avatar');
  if (ownerAvatar) {
    const name = settings.ownerName || settings.guestHouseName || 'GH';
    ownerAvatar.textContent = name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
  }
}

function updateDateDisplay() {
  const el = document.getElementById('current-date');
  if (el) {
    const now = new Date();
    el.textContent = now.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }
}

export function escHtml(v) {
  if (v == null) return '';
  return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ============================================================
// FORM VALIDATION HELPER
// ============================================================
export function validateForm(data, rules) {
  const errors = [];
  for (const [field, rule] of Object.entries(rules)) {
    const val = data[field];
    if (rule.required && (!val || (typeof val === 'string' && !val.trim()))) {
      errors.push(`${rule.label || field} is required`);
    }
    if (rule.pattern && val && !rule.pattern.test(val)) {
      errors.push(rule.message || `${rule.label || field} is invalid`);
    }
    if (rule.min !== undefined && val !== undefined && val !== '' && parseFloat(val) < rule.min) {
      errors.push(`${rule.label || field} must be at least ${rule.min}`);
    }
  }
  return errors;
}