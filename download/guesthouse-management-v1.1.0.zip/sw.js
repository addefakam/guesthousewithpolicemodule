const CACHE_NAME = 'ghms-v1.1.0';
const ASSETS = [
  './',
  './index.html',
  './css/styles.css',
  './js/app.js',
  './js/data.js',
  './js/i18n.js',
  './js/modules/dashboard.js',
  './js/modules/rooms.js',
  './js/modules/guests.js',
  './js/modules/reservations.js',
  './js/modules/calendar.js',
  './js/modules/daytime.js',
  './js/modules/expenses.js',
  './js/modules/resources.js',
  './js/modules/reports.js',
  './js/modules/housekeeping.js',
  './js/modules/activity-log.js',
  './js/modules/users.js',
  './js/modules/settings.js',
  './manifest.json',
];

// Install - cache app shell
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(ASSETS);
    })
  );
  self.skipWaiting();
});

// Activate - clean old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

// Fetch - cache-first for assets, network-first for CDN resources
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // For CDN resources (fonts, chart.js, lucide), try network first, fall back to cache
  if (url.hostname === 'cdn.jsdelivr.net' || url.hostname === 'unpkg.com' || url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(
      fetch(event.request).then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => caches.match(event.request))
    );
    return;
  }

  // For local assets, try cache first, then network
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response.ok && url.origin === self.location.origin) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      });
    })
  );
});